import { RouterModule, Routes } from '@angular/router';
import { MainPageComponent } from './components/main-page/main-page.component';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { NgModule } from '@angular/core';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { AdminRegistrationComponent } from './components/admin-registration/admin-registration.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AdminCoursesComponent } from './components/admin-courses/admin-courses.component';
import { AdminUsersComponent } from './components/admin-users/admin-users.component';
import { AdminProfileComponent } from './components/admin-profile/admin-profile.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { UserCoursesComponent } from './components/user-courses/user-courses.component';
import { UserMyCoursesComponent } from './components/user-mycourses/user-mycourses.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { AdminCoursesMaterialComponent } from './components/admin-courses-material/admin-courses-material.component';

export const routes: Routes = [
  { path: '', component: MainPageComponent }, // Default route
  { path: 'user-login', component: UserLoginComponent },
  { path: 'user-registration', component: UserRegistrationComponent },
  { path: 'register', component: UserRegistrationComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'admin-registration', component: AdminRegistrationComponent },
  { path: '', redirectTo: '/admin-login', pathMatch: 'full' },
  { path: 'admin-dashboard', component: AdminDashboardComponent },
  { path: 'admin-courses', component: AdminCoursesComponent },
  { path: 'admin-users', component: AdminUsersComponent },
  { path: 'admin-profile', component: AdminProfileComponent },
  { path: '', redirectTo: '/admin-dashboard', pathMatch: 'full' },
  { path: '', redirectTo: 'user-dashboard', pathMatch: 'full' }, // Redirect to user dashboard by default
  { path: 'user-dashboard', component: UserDashboardComponent },
  { path: 'user-courses', component: UserCoursesComponent },
  { path: 'user-mycourses', component: UserMyCoursesComponent },
  { path: 'user-profile', component: UserProfileComponent },
  { path: 'admin-courses-material', component: AdminCoursesMaterialComponent },
  { path: '**', redirectTo: 'user-dashboard' },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
