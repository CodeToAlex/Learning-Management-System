import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AdminCoursesComponent } from './components/admin-courses/admin-courses.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { AdminProfileComponent } from './components/admin-profile/admin-profile.component';
import { AdminRegistrationComponent } from './components/admin-registration/admin-registration.component';
import { AdminUsersComponent } from './components/admin-users/admin-users.component';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { MainPageComponent } from './components/main-page/main-page.component';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { CommonModule } from '@angular/common';
import { AdminCoursesMaterialComponent } from './components/admin-courses-material/admin-courses-material.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { UserCoursesComponent } from './components/user-courses/user-courses.component';
import { UserMyCoursesComponent } from './components/user-mycourses/user-mycourses.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    RouterOutlet,
    // BrowserModule,
    FormsModule,
    HttpClientModule,
    AdminCoursesComponent,
    AdminDashboardComponent,
    AdminLoginComponent,
    AdminProfileComponent,
    AdminRegistrationComponent,
    AdminUsersComponent,
    UserLoginComponent,
    MainPageComponent,
    UserRegistrationComponent,
    AdminCoursesMaterialComponent,
    UserProfileComponent,
    UserCoursesComponent,
    UserMyCoursesComponent,
    UserDashboardComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'LMS-frontend';
}
