import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-admin-registration',
  standalone: true,
  imports: [FormsModule, CommonModule, HttpClientModule, RouterLink],
  templateUrl: './admin-registration.component.html',
  styleUrls: ['./admin-registration.component.css'],
})
export class AdminRegistrationComponent {
  register = {
    fullName: '',
    email: '',
    phone: '',
    dob: '',
    gender: '',
    password: '',
  };

  constructor(private http: HttpClient) {}

  onRegister(event: Event) {
    event.preventDefault();

    if (!this.register.fullName.trim()) {
      alert('Full Name is required.');
      return;
    }
    if (!/^\d{10}$/.test(this.register.phone)) {
      alert('Phone number must be exactly 10 digits.');
      return;
    }
    if (
      !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(
        this.register.email
      )
    ) {
      alert('Invalid email format.');
      return;
    }
    if (!this.register.password || this.register.password.length < 6) {
      alert('Password must be at least 6 characters long.');
      return;
    }

    this.http
      .post<any>('http://localhost:8080/admin/register', this.register)
      .subscribe(
        (response) => {
          console.log(response.message);
          alert(response.message);
        },
        (error) => {
          console.error('Registration failed', error);
          alert('Error registering admin.');
        }
      );
  }
}
