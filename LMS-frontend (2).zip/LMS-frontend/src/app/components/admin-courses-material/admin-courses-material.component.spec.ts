import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCoursesMaterialComponent } from './admin-courses-material.component';

describe('AdminCoursesMaterialComponent', () => {
  let component: AdminCoursesMaterialComponent;
  let fixture: ComponentFixture<AdminCoursesMaterialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminCoursesMaterialComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminCoursesMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
