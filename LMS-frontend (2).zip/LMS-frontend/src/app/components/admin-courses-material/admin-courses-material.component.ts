import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-admin-courses-material',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    HttpClientModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './admin-courses-material.component.html',
  styleUrls: ['./admin-courses-material.component.css'],
})
export class AdminCoursesMaterialComponent {
  course = { name: '', videos: '', notes: '', assignments: '' };

  saveMaterials() {
    alert('Materials saved successfully!');
  }
}
