import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
})
export class UserProfileComponent implements OnInit {
  userData: any = {};
  activeSection: string = 'personal-info';
  editMode: boolean = false;

  constructor(private userService: UserService) {}

  ngOnInit() {
    const storedData = localStorage.getItem('userData');
    if (storedData) {
      this.userData = JSON.parse(storedData); // Load from localStorage if available
    } else {
      this.fetchUserProfile(); // Fetch from API if not available
    }
  }

  fetchUserProfile() {
    this.userService.getUserProfile().subscribe({
      next: (data) => {
        this.userData = data;
      },
      error: (error) => {
        console.error('Error fetching profile:', error);
      },
    });
  }

  toggleEditProfile() {
    this.editMode = !this.editMode;
  }

  saveProfile() {
    localStorage.setItem('userData', JSON.stringify(this.userData));
    this.editMode = false;
    alert('Profile updated successfully!');
  }

  cancelEdit() {
    this.editMode = false;
    this.fetchUserProfile();
  }
}
