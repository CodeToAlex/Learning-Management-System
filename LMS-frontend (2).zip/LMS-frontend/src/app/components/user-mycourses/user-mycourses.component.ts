import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { EnrollmentService } from '../../services/enrollmentservice.service';

@Component({
  selector: 'app-user-mycourses',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-mycourses.component.html',
  styleUrls: ['./user-mycourses.component.css'],
})
export class UserMyCoursesComponent implements OnInit {
  myCourses: any[] = [];
  showMaterials: boolean = false;
  selectedCourse: any = null;

  constructor(private enrollmentService: EnrollmentService) {}

  ngOnInit() {
    this.loadMyCourses();
  }

  loadMyCourses() {
    this.enrollmentService.getUsers().subscribe(
      (users) => {
        this.myCourses = users.filter((user) => user.status === 'APPROVED');
      },
      (error) => console.error('Error fetching enrolled courses:', error)
    );
  }

  openMaterials(course: any) {
    if (course) {
      this.selectedCourse = course;
      this.showMaterials = true;
    }
  }

  closeMaterials() {
    this.showMaterials = false;
    this.selectedCourse = null;
  }
}
