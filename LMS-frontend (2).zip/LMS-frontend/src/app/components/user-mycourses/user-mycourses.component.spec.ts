import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserMycoursesComponent } from './user-mycourses.component';

describe('UserMycoursesComponent', () => {
  let component: UserMycoursesComponent;
  let fixture: ComponentFixture<UserMycoursesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserMycoursesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserMycoursesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
