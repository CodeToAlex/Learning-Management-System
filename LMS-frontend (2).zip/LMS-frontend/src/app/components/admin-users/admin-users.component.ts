import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { EnrollmentService } from '../../services/enrollmentservice.service';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.css'],
})
export class AdminUsersComponent {
  users: any[] = [];

  constructor(private enrollmentService: EnrollmentService) {}

  ngOnInit() {
    this.loadUsers();
  }

  loadUsers() {
    this.enrollmentService.getUsers().subscribe(
      (data) => (this.users = data),
      (error) => console.error('Error fetching users:', error)
    );
  }
  approveUser(user: any) {
    this.enrollmentService.approveUser(user.id).subscribe(() => {
      user.status = 'APPROVED';
      alert('User Approved!');
    });
  }

  blockUser(user: any) {
    this.enrollmentService.blockUser(user.id).subscribe(() => {
      user.status = 'BLOCKED';
      alert('User Blocked!');
    });
  }

  resetPassword(user: any) {
    console.log(`Resetting password for user: ${user.name}`);
    alert(`Password reset link sent to ${user.email}`);
  }
}
