import { Component } from '@angular/core';

@Component({
  selector: 'app-components',
  imports: [],
  templateUrl: './components.component.html',
  styleUrl: './components.component.css'
})
export class ComponentsComponent {

}
