import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [FormsModule, CommonModule, HttpClientModule, RouterModule],
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css'],
})
export class AdminLoginComponent {
  email: string = '';
  password: string = '';

  constructor(private adminService: AdminService, private router: Router) {}

  onLogin(event: Event) {
    event.preventDefault();

    if (!this.email || !this.password) {
      alert('Please enter email and password.');
      return;
    }

    this.adminService.loginAdmin(this.email, this.password).subscribe(
      (response) => {
        alert(`Welcome ${response.fullName}!`);
        localStorage.setItem('admin', JSON.stringify(response));
        this.router.navigate(['/admin-dashboard']);
      },
      (error) => {
        alert('Invalid email or password.');
        console.error('Login failed:', error);
      }
    );
  }

  navigateToRegister() {
    this.router.navigate(['/admin-registration']);
  }
}
