import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css'],
})
export class UserLoginComponent {
  email: string = '';
  password: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  onLogin(event: Event) {
    event.preventDefault();

    if (!this.email || !this.password) {
      alert('Please enter email and password.');
      return;
    }

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    this.http
      .post<any>(
        'http://localhost:8080/users/login',
        { email: this.email, password: this.password },
        { headers, withCredentials: true }
      )
      .subscribe({
        next: (response) => {
          if (response.userId && response.token) {
            alert('Login Successful!');
            localStorage.setItem('userId', response.userId.toString());
            localStorage.setItem('fullName', response.fullName);
            localStorage.setItem('sessionToken', response.token);

            setTimeout(() => {
              this.router.navigate(['/user-dashboard']);
            }, 100);
          } else {
            alert(response.message || 'Login failed!');
          }
        },
        error: (error) => {
          console.error('Login error:', error);
          alert('Login failed! Please check your credentials.');
        },
      });
  }
}
