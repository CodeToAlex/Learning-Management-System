import { Component, OnInit } from '@angular/core';
import { CourseService } from '../../services/course.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { EnrollmentService } from '../../services/enrollmentservice.service';

@Component({
  selector: 'app-user-courses',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-courses.component.html',
  styleUrls: ['./user-courses.component.css'],
})
export class UserCoursesComponent implements OnInit {
  courses: any[] = [];
  showForm = false;
  selectedCourse: any = {};
  form = { fullName: '', contact: '', email: '' };

  constructor(
    private courseService: CourseService,
    private enrollmentService: EnrollmentService
  ) {}

  ngOnInit() {
    this.loadCourses();
  }

  loadCourses() {
    this.courseService.getCourses().subscribe(
      (data) => {
        console.log('Fetched courses:', data);
        this.courses = data;
      },
      (error) => console.error('Error fetching courses:', error)
    );
  }

  openCourseForm(course: any) {
    this.selectedCourse = course;
    this.showForm = true;
  }

  enroll() {
    const token = localStorage.getItem('token');

    console.log('Retrieved token:', token);

    if (!token) {
      alert('You must be logged in to enroll in a course.');
      return;
    }

    const userEnrollment = {
      name: this.form.fullName,
      email: this.form.email,
      contact: this.form.contact,
      course: this.selectedCourse.name,
      status: 'PENDING',
    };

    this.enrollmentService.enrollUser(userEnrollment).subscribe(
      (response) => {
        alert(`Successfully enrolled in ${this.selectedCourse.name}`);
        this.showForm = false;
      },
      (error) => {
        console.error('Enrollment failed:', error);
        alert('Enrollment failed. Try again.');
      }
    );
  }
}
