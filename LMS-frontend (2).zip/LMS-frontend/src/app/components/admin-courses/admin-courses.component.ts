import { Component, OnInit } from '@angular/core';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet,
} from '@angular/router';
import { CourseService } from '../../services/course.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-admin-courses',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    HttpClientModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './admin-courses.component.html',
  styleUrls: ['./admin-courses.component.css'],
})
export class AdminCoursesComponent implements OnInit {
  courses: any[] = [];
  showForm = false;
  isEdit = false;
  course = { id: 0, name: '', description: '', duration: '', available: true };

  constructor(private courseService: CourseService, private router: Router) {}

  ngOnInit() {
    this.loadCourses();
  }

  loadCourses() {
    this.courseService.getCourses().subscribe(
      (data) => {
        this.courses = data;
      },
      (error) => console.error('Error fetching courses:', error)
    );
  }

  openCourseForm() {
    this.showForm = true;
    this.isEdit = false;
    this.course = {
      id: 0,
      name: '',
      description: '',
      duration: '',
      available: true,
    };
  }

  editCourse(course: any) {
    this.showForm = true;
    this.isEdit = true;
    this.course = { ...course };
  }

  saveCourse() {
    if (!this.course.name || !this.course.duration) {
      alert('Please fill in all fields');
      return;
    }

    const courseData = {
      name: this.course.name,
      description: this.course.description,
      duration: this.course.duration,
      available: this.course.available,
    };

    if (this.isEdit) {
      this.courseService.updateCourse(this.course.id, courseData).subscribe(
        () => {
          console.log('Course updated');
          this.loadCourses();
        },
        (error) => console.error('Error updating course:', error)
      );
    } else {
      this.courseService.addCourse(courseData).subscribe(
        () => {
          console.log('Course added');
          this.loadCourses();
        },
        (error) => console.error('Error adding course:', error)
      );
    }
  }

  deleteCourse(id: number) {
    this.courseService.deleteCourse(id).subscribe(() => {
      this.loadCourses();
      alert('Course deleted!');
    });
  }

  closeForm() {
    this.showForm = false;
  }

  logout() {
    alert('Logged out successfully');
    this.router.navigate(['/admin-login']);
  }
}
