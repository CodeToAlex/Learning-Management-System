import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-profile',
  standalone: true,
  imports: [FormsModule, CommonModule, HttpClientModule],
  templateUrl: './admin-profile.component.html',
  styleUrls: ['./admin-profile.component.css'],
})
export class AdminProfileComponent implements OnInit {
  adminEmail: string = '';
  userData: any = null;
  editMode: boolean = false;
  activeSection: string = 'personal-info';

  constructor(private adminService: AdminService, private router: Router) {}

  ngOnInit(): void {
    const storedAdmin = localStorage.getItem('admin');
    if (storedAdmin) {
      const admin = JSON.parse(storedAdmin);
      this.adminEmail = admin.email;
      this.loadAdminProfile();
    } else {
      this.router.navigate(['/admin-login']);
    }
  }

  loadAdminProfile(): void {
    if (!this.adminEmail) return;

    this.adminService.getAdminByEmail(this.adminEmail).subscribe(
      (response) => (this.userData = response),
      (error) => console.error('Error fetching admin data:', error)
    );
  }

  toggleEditProfile(): void {
    this.editMode = true;
  }

  saveProfile(): void {
    this.adminService.updateAdmin(this.userData).subscribe(
      () => (this.editMode = false),
      (error) => console.error('Error updating admin:', error)
    );
  }

  cancelEdit(): void {
    this.editMode = false;
    this.loadAdminProfile();
  }
}
