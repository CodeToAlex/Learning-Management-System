import { Component } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-user-registration',
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    HttpClientModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css'],
})
export class UserRegistrationComponent {
  register = {
    fullName: '',
    email: '',
    phone: '',
    dob: '',
    gender: '',
    password: '',
  };

  constructor(private http: HttpClient) {}

  onRegister(event: Event) {
    event.preventDefault();

    if (!this.register.fullName.trim()) {
      alert('Full Name is required.');
      return;
    }
    if (!/^\d{10}$/.test(this.register.phone)) {
      alert('Phone number must be exactly 10 digits.');
      return;
    }
    if (
      !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(
        this.register.email
      )
    ) {
      alert('Invalid email format.');
      return;
    }
    if (!this.register.password || this.register.password.length < 6) {
      alert('Password must be at least 6 characters long.');
      return;
    }

    this.http
      .post('http://localhost:8080/users/register', this.register)
      .subscribe(
        (response) => {
          alert('User Registered Successfully!');
        },
        (error) => {
          alert('Registration failed! Please try again.');
        }
      );
  }
}
