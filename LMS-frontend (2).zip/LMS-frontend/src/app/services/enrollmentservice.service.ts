import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EnrollmentService {
  private userApiUrl = 'http://localhost:8080/userenrollment';
  private courseApiUrl = 'http://localhost:8080/courseenrollment';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token =
      typeof localStorage !== 'undefined'
        ? localStorage.getItem('token')
        : null;

    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    });
  }

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.userApiUrl, {
      headers: this.getAuthHeaders(),
    });
  }

  enrollUser(user: any): Observable<string> {
    const token = localStorage.getItem('token');

    if (!token) {
      console.error('No token found in localStorage');
      return new Observable<string>((observer) => {
        observer.error('No authentication token found.');
      });
    }

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    });

    return this.http.post<string>(
      'http://localhost:8080/userenrollment/enroll',
      user,
      { headers }
    );
  }

  approveUser(id: number): Observable<string> {
    return this.http.put<string>(
      `${this.userApiUrl}/approve/${id}`,
      {},
      { headers: this.getAuthHeaders() }
    );
  }

  blockUser(id: number): Observable<string> {
    return this.http.put<string>(
      `${this.userApiUrl}/block/${id}`,
      {},
      { headers: this.getAuthHeaders() }
    );
  }

  getCourses(): Observable<any[]> {
    return this.http.get<any[]>(this.courseApiUrl, {
      headers: this.getAuthHeaders(),
    });
  }
}
